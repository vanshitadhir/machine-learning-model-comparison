# Machine Learning Model Comparison: Heart Disease

Exploratory data analysis and comparison of four classifiers on a heart disease dataset.

## Contents
- `heart_disease_analysis.ipynb` – full notebook with code, outputs and plots
- `heart_dataset.csv` – dataset
- `plots/` – all output charts as PNG images

## Results
| Model | Accuracy |
|---|---|
| Logistic Regression | 86.13% |
| KNN | 88.66% |
| Naive Bayes | 85.71% |
| Random Forest | **94.54%** |

## Run
```bash
pip install pandas matplotlib seaborn scikit-learn jupyter
jupyter notebook heart_disease_analysis.ipynb
```
